<?php

namespace App\Models;

class Product
{
    public function getName(): string
    {
        return 'Кофемолка Deluxe 3000';
    }
}
