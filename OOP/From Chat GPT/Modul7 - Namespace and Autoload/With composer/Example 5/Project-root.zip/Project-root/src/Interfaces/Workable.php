<?php

namespace App\Interfaces;

interface Workable
{
    public function work(): string;
}
