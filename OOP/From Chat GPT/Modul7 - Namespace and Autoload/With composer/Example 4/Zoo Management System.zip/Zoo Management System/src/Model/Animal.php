<?php

namespace App\Model;

abstract class Animal 
{
    protected $name;

    public function __construct($name)
    {
        $this->name = $name;
    }

    public function getName()
    {
        return $this->name;
    }

    abstract public function makeSound(): string;
}
