<?php

namespace Classes\Interfaces;

interface SpellCaster
{
    public function castSpell(string $spell): void;
}
