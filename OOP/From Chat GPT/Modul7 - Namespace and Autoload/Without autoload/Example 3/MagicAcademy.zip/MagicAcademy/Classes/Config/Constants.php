<?php

namespace Classes\Config;

class Constants
{
    public const DEFAULT_MANA = 100;
}