<?php

namespace App\Characters;

interface Hero
{
    public function attack(): void;
}
