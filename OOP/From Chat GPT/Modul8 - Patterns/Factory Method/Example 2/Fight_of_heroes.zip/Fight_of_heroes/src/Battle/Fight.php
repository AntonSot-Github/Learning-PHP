<?php

// namespace App\Battle;

// use App\Heroes\HeroInterface;
// use App\Strategies\BattleStrategyInterface;

// class Fight implements BattleStrategyInterface
// {
//     public function execute(HeroInterface $hero): string
//     {
        
//     }
// }