<?php

namespace App\Contracts;

interface Defendable 
{
    public function defend(): void;
}
