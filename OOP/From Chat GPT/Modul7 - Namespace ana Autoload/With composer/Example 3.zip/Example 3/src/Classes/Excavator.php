<?php

namespace App\Classes;

class Excavator
{
    public function start():string
    {
        return "Excavator has started" . PHP_EOL;
    }
}
