<?php

echo "\n\n ======== Повертаємо значення ===============\n";

function f1() {
    $b = 4;
    return $b + 10;
}

$a = f1() + 100;
echo $a, "\n";
echo 100 + f1();
echo "\n";
echo 'Return: '.f1();
var_dump(f1());

echo "\n\n ==========генерую число =========\n";

$a = 200;
$b = 250;

function f2(){
    global $a, $b;
    return rand($a, $b);
}

$c = f2();
echo $c, "\n";
echo f2() + f2(), "\n";

echo "\n\n ======== зупинка функції ===============\n";

function f4() {
    echo 1, "\n";
    return;
    echo 2, "\n";
}

f4();

echo "\n\n ======== аргументи ===============\n";

function f5($a, $b){
    return rand($a, $b);
}

$ri = f5(1000, 1100);
echo "random: ".$ri, "\n";

$ri = f5(10, 35);
echo "random: ".$ri, "\n";

$min = 44;
$ri = f5($min, 65);
echo "random: ".$ri, "\n";

$max = 77;
$ri = f5($min, $max);
echo "random: ".$ri, "\n";

$ri = f5(f1(), $max);
echo "random: ".$ri, "\n";

echo "\n\n ======== помилки ===============\n";

$ri = f5(10,20,30);
echo "помилка: ".$ri, "\n";

echo "\n\n ======== аргументи по дефолту ===============\n";

function f6(
            $a = 0, 
            $b = 100,
            )
{
    return rand($a, $b);
}

$ri = f6(1000,2000);
echo "rand: ".$ri, "\n";
$ri = f6();
echo "rand: ".$ri, "\n";
$ri = f6(50);
echo "rand: ".$ri, "\n";

echo "\n\n ======== приклад використання ===============\n";

function systemInfo($fileName = 'report'){
    $date = date('Y_m_d_h_i', time());
    exec("systeminfo > {$fileName}_{$date}.txt");
    // exec("ipconfig >> ".$fileName."_".$date.".txt");
}

systemInfo('bug');