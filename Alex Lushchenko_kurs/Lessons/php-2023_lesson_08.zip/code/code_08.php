<?php

// Повернення значення

function f1() {
    $b = 4;
    return $b;
}

$a = f1();
echo $a, "\n";
var_dump($a); // is_null()
echo 10 + f1() , "\n";

// 1. Виключити глобальні змінні...
// 2. Використовувати функцію у виразах привласнювання
// 3. Гнучкою...(приклад с echo)

// Функція повинна генерувати випадкове число від $a, $b

$a = 50;
$b = 100;
$c;

function f2() {
    global $a, $b, $c;
    $c  = rand($a, $b);
}

f2();
echo "random: $c", "\n";

function f3() {
    global $a, $b;
    return rand($a, $b);
}

// $randomInt = f3();
// echo "random: $randomInt", "\n";
echo "random: ".f3(), "\n";

echo "\n\n ======== зупинка функції ===============\n";

function f4() {
    echo 1, "\n";
    echo 2, "\n";
    
    return;
}

f4();

echo "\n\n ======== аргументи функції ===============\n";

function f5($a, $b) {
    return rand($a, $b);
}

$ri = f5(22, 30); 
echo "random: ".$ri, "\n";

$ri = f5(100, 150); 
echo "random: ".$ri, "\n";

$min = 77;

$ri = f5($min, 90); 
echo "random: ".$ri, "\n";

$max = 140;

$ri = f5($min, $max); 
echo "random: ".$ri, "\n";

echo "\n\n ======== помилка - забудемо аргументи ===============\n";

$ri = f5(200, 300, 500);
echo "random: ".$ri, "\n";


echo "\n\n ======== аргументи по дефолту ===============\n";

function f6($a = 0, $b = 100) {
    return rand($a, $b);
}

$c = f6();

echo "random: ".$c, "\n";

// кома

echo "\n\n ======== приклад використання ===============\n";

function systemInfo($fileName = 'report'){
    $date = date('Y_m_d_h_i', time());

    exec ("systeminfo >".$fileName."_".$date.".txt");
    exec ("ipconfig >>".$fileName."_".$date.".txt");
}

systemInfo();


