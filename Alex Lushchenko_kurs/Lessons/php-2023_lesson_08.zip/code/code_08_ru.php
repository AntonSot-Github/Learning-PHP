<?php
echo "\n\n ======== возвращаемые значения ===\n";

function f1() {
    $b = 4;
    return $b;
}

$a = f1() + 100;
echo $a, "\n";
echo 'n:'.f1(), "\n";
// var_dump($a); // is_null

$a = 100;
$b = 200;

function f2() {
    global $a, $b;
    return rand($a, $b);
}

$c = f2();
echo $c,"\n";

echo "\n\n ======== остановка функции ===\n";

function f4() {
    return ;
    echo 1, "\n";
    return ;
    echo 2, "\n";
    return ;
}

f4();

echo "\n\n ======== аргументы ===\n";


function f5($a, $b) {
    return rand($a, $b);
}

$c = f5(1, 10);
echo $c,"\n";

$c = f5(20, 30);
echo $c,"\n";

$min = 50;

$c = f5($min, 60);
echo $c,"\n";

$max = 100;

$c = f5($min, $max);
echo $c,"\n";

$c = f5(f1()*10, 45);
var_dump($c);

echo "\n\n ======== ошибки ===\n";

$c = f5(1000,2000,3000);
echo $c,"\n";

echo "\n\n ========  аргументы по умолчанию ===\n";

function f6($min = 0, $max = 300) {
    return rand($min, $max);
}

$c = f6();
echo $c,"\n";

echo "\n\n ========  практика ===\n";

function systemInfo($fileName = 'report') {
    $date = date('Y_m_d_h_i', time());

    exec("systeminfo > {$fileName}_{$date}.txt");
}

systemInfo('go');